package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController(value="/")
public class MyController {

	@GetMapping(value="/")
	public String base(){
		String str= "<h1>Index Page</h1>";
		str += "<h1><a href='admin/page1'>Page1</h1>";
		str += "<h1><a href='admin/page2'>Page2</h1>";
		return str;
	}
	
	@GetMapping(value="/admin/page1")
	public String page1(){
		return "<h1>Page1</h1>";
		
	}
	@GetMapping(value="/admin/page2")
	public String page2(){
		return "<h1>Page2</h1>";
	}
}

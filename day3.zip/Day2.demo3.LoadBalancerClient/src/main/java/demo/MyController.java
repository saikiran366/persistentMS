package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

@RestController
public class MyController {
	@Autowired
	private WebClient.Builder builder;
	
	@GetMapping
	public String hello(){
		Mono<String> str = builder.build().get().uri("http://say-hello/emps").retrieve().bodyToMono(String.class);
		return "hello from LBClientApp<br/>"+  str.block();
	/*	WebClient webClient = WebClient.create("http://localhost:8085/emps"); 
		Mono<String> str = webClient.get()
		        .retrieve()
		        .bodyToMono(String.class);
		return "hello from LBClientApp<br/>"+  str.block();
	*/
	}
}

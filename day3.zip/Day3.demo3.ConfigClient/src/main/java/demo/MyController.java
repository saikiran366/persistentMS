package demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController(value="/")
@RefreshScope
public class MyController {
	@Value("${data:Hello default}")
	private String data = "Temp";
	@GetMapping
	public String hello(){
		return "<h1>Hello From MyController </h1><h2>Value of  data =  " + data + "</h2>";
	}
}

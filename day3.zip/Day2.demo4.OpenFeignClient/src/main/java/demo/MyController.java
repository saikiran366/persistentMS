package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	@Autowired
	private Demo1RestProviderClient client;
	
	@GetMapping
	public String process(){
		List<Emp> list = client.list();
		System.out.println("in process " + list);
		return "<h1>"+ list.size() + "</h1>";
	}
}

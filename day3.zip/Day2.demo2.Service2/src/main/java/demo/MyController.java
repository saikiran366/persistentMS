package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/")
public class MyController {
	@GetMapping()
	public String base(){
		System.out.println("in / of Service2");
		return "<html><h1>service2</h1></html>";
	}
	@GetMapping(value="/emps")
	public String emps(){
		System.out.println("in /emps of Service2");
		return "<h1 style='background-color:green'>emps from Service1</h1>";
	}
	
}

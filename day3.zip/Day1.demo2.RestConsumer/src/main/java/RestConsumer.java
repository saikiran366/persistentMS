import org.springframework.web.client.RestTemplate;

public class RestConsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestTemplate resttemplate = new RestTemplate();
		String str = resttemplate.getForObject("http://localhost:8080", String.class);
		System.out.println(str);
	}

}

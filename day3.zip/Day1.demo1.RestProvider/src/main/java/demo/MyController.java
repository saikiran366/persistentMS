package demo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController(value="/")
public class MyController {
	List<Emp> list  = new ArrayList<>();
	public MyController() {
		Emp e1 = new Emp();
		e1.setEmpno(1);e1.setEname("Vaishali"); e1.setSalary(1111);
		list.add(e1);
	}
	
	@PostMapping(value="/emps")
	public String add(Emp e){
		System.out.println("add invoked with " + e);
		list.add(e);
		return "success";
	}
	@GetMapping(value="/emps")
	public List<Emp> list(){
		System.out.println("List invoked ");
		return list;
	}
	
	@GetMapping
	public String hello(){
		System.out.println("hello of demo1RestProvider " + new Date());
		return "<html><h1>Hello World from Day1.demo1.RestProvider !!</h1></html>";
	}
}

package demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name= "demo1", url="http://localhost:8080")
public interface Demo1RestProviderClient {
	@PostMapping(value="/emps")
	public String add(Emp e);

	@GetMapping(value="/emps")
	public List<Emp> list();
			
	@GetMapping(value="/")
			public String hello();
}
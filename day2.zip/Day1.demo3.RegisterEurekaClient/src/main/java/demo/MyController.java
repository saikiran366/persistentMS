package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	@GetMapping(value="/myapp")
	public String hello(){
		System.out.println("hello from MyController invoked ");
		return "<h1 style='background-color:red'>Hello</h1>";
	}
}

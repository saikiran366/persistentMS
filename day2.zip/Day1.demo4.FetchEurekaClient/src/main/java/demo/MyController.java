package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class MyController {
	@Autowired
	private RestTemplate resttemplate;
	
	@GetMapping(value="/")
	public String hello(){
		System.out.println("hello from MyController invoked ");
	//invoke Client1 url and then return that data as String....
		
		String str = resttemplate.getForObject("http://client1/myapp", String.class);
		return "<h1>Getting data from Client 1 <h1><br/> The Data is  "+ str;
	}
}
